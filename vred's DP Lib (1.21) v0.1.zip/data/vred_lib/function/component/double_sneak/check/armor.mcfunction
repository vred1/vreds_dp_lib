execute if items entity @s armor.head *[custom_data~{vred_lib:{armor:{double_sneak_effect:true}}}] run function vred_lib:component/double_sneak/check/a {slot:"armor.head"}
execute if items entity @s armor.chest *[custom_data~{vred_lib:{armor:{double_sneak_effect:true}}}] run function vred_lib:component/double_sneak/check/a {slot:"armor.chest"}
execute if items entity @s armor.legs *[custom_data~{vred_lib:{armor:{double_sneak_effect:true}}}] run function vred_lib:component/double_sneak/check/a {slot:"armor.legs"}
execute if items entity @s armor.feet *[custom_data~{vred_lib:{armor:{double_sneak_effect:true}}}] run function vred_lib:component/double_sneak/check/a {slot:"armor.feet"}
