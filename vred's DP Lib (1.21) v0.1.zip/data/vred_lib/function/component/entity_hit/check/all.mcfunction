execute if items entity @s armor.head *[custom_data~{vred_lib:{all:{entity_hit_effect:true}}}] run function vred_lib:component/entity_hit/check/a {slot:"armor.head"}
execute if items entity @s armor.chest *[custom_data~{vred_lib:{all:{entity_hit_effect:true}}}] run function vred_lib:component/entity_hit/check/a {slot:"armor.chest"}
execute if items entity @s armor.legs *[custom_data~{vred_lib:{all:{entity_hit_effect:true}}}] run function vred_lib:component/entity_hit/check/a {slot:"armor.legs"}
execute if items entity @s armor.feet *[custom_data~{vred_lib:{all:{entity_hit_effect:true}}}] run function vred_lib:component/entity_hit/check/a {slot:"armor.feet"}

execute if items entity @s weapon.mainhand *[custom_data~{vred_lib:{all:{entity_hit_effect:true}}}] run function vred_lib:component/entity_hit/check/a {slot:"weapon.mainhand"}
execute if items entity @s weapon.offhand *[custom_data~{vred_lib:{all:{entity_hit_effect:true}}}] run function vred_lib:component/entity_hit/check/a {slot:"weapon.offhand"}
